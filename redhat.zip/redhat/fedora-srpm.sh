#!/bin/bash

make IS_FEDORA=1 DIST=".fc42" BUILDID="" BUILD=200 dist-srpm
